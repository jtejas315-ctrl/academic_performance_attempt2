# Academic Performance Dashboard — UI Upgrade

This version adds a modern Streamlit web interface while preserving the original hardened command-line application and its data model.

## Web dashboard quick start (Windows / VS Code)

1. Extract the ZIP and open the `academic_performance_dashboard` folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Activate your virtual environment (if it already exists):
   ```powershell
   .\venv\Scripts\Activate.ps1
   ```
4. Install the updated dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
5. Start the browser dashboard:
   ```powershell
   python -m streamlit run dashboard_app.py
   ```
   Or double-click `run_dashboard.bat` after installing the dependencies.
6. Streamlit will print a local URL, usually `http://localhost:8501`. Open it in your browser.

## Features in the new UI

- Overview with KPI cards (record count, average, pass rate and at-risk count)
- Subject average chart and grade distribution
- Recent records and anomaly highlights
- Search and filter student records by text, subject and status
- Add records through a validated form (prevents duplicate student/subject/term entries in the UI)
- CSV upload with preview, row validation and duplicate checks
- Generate and download CSV, Markdown and PNG reports
- Alerts page for below-pass scores and statistical outliers
- Reload saved records from the integrity-protected data store

## Original command-line version

The original CLI remains available:
```powershell
python academic_dashboard.py
```

## Project structure

- `academic_dashboard.py` — original CLI, validation, analytics, secure persistence and report generator
- `dashboard_app.py` — new Streamlit UI
- `data/sample_import.csv` — example CSV for import testing
- `requirements.txt` — dependencies for the CLI charting and web UI
- `run_dashboard.bat` — Windows launcher

The dashboard shares the original records store (`data/records.json`) and persistence checks. If you have existing records in your current project folder, copy your `data/records.json` and `data/records.sha256` into the updated folder's `data/` directory before launching, so those records carry over.
