from __future__ import annotations

import csv
import io
import sys
from pathlib import Path
from typing import Any

import streamlit as st

# Import the existing, tested data model, persistence, validation and report functions.
import academic_dashboard as core

BASE_DIR = Path(__file__).resolve().parent

st.set_page_config(
    page_title="Academic Performance Dashboard",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
      @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap');
      html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
      .stApp { background: #f5f7fb; }
      h1, h2, h3 { font-family: 'Manrope', sans-serif; color: #17233b; }
      [data-testid="stSidebar"] { background: #101c34; }
      [data-testid="stSidebar"] * { color: #eef3ff !important; }
      [data-testid="stSidebar"] [data-testid="stRadio"] label { padding: 8px 4px; }
      [data-testid="stMetric"] { background: white; border: 1px solid #e5eaf2; padding: 16px 18px; border-radius: 14px; box-shadow: 0 3px 12px rgba(28,44,74,.04); }
      [data-testid="stMetricLabel"] { color: #64748b; }
      [data-testid="stMetricValue"] { color: #182943; }
      div[data-testid="stForm"] { background: white; border: 1px solid #e5eaf2; padding: 20px; border-radius: 16px; }
      div[data-testid="stDataFrame"] { border-radius: 12px; overflow: hidden; }
      .hero { background: linear-gradient(120deg,#172b50,#2858a6); border-radius: 18px; padding: 24px 28px; color: white; margin-bottom: 16px; }
      .hero h1 { color: white !important; margin: 0 0 5px 0; }
      .hero p { color: #d9e6ff; margin: 0; }
      .section-note { color: #64748b; margin-top: -8px; }
      .pill { display:inline-block; padding:4px 10px; border-radius:999px; font-size:12px; font-weight:700; background:#eaf1ff; color:#2458ad; }
    </style>
    """,
    unsafe_allow_html=True,
)


def load_data() -> list[core.PerformanceRecord]:
    return core.load_records_with_recovery()


def refresh_data() -> None:
    st.session_state.records = load_data()


if "records" not in st.session_state:
    st.session_state.records = load_data()

records: list[core.PerformanceRecord] = st.session_state.records
engine = core.AnalyticsEngine(records)
summary = engine.executive_summary()

with st.sidebar:
    st.markdown("## 🎓 Academic Insights")
    st.caption("Student performance • Analytics • Reports")
    page = st.radio(
        "Navigation",
        ["Overview", "Student Records", "Add Record", "Import CSV", "Reports", "Alerts"],
        label_visibility="collapsed",
    )
    st.divider()
    st.markdown("**Thresholds**")
    st.caption(f"Pass mark: {core.PASS_THRESHOLD:.0f} / 100")
    st.caption(f"Honors: {core.HONORS_THRESHOLD:.0f} / 100")
    st.caption(f"Records stored securely in `{core.DATA_DIR.name}/records.json` with integrity checking.")
    if st.button("↻ Reload saved data", use_container_width=True):
        refresh_data()
        st.rerun()


def header(title: str, subtitle: str) -> None:
    st.markdown(
        f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>',
        unsafe_allow_html=True,
    )


def records_frame(rows: list[core.PerformanceRecord]):
    import pandas as pd

    return pd.DataFrame(
        [
            {
                "Student ID": r.student_id,
                "Student": r.student_name,
                "Subject": r.subject,
                "Score": r.score,
                "Grade": r.grade,
                "Status": r.status.replace("_", " "),
                "Term": r.term,
                "Date": r.recorded_at,
            }
            for r in rows
        ]
    )


if page == "Overview":
    header("Academic Performance", "A clear view of student outcomes, trends and areas that need attention.")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Records", f"{summary['count']:,}")
    m2.metric("Average score", f"{summary['mean']:.1f}%", delta=f"Median {summary['median']:.1f}")
    m3.metric("Pass rate", f"{summary['pass_rate']:.1f}%")
    m4.metric("At risk", f"{summary['at_risk_count']}", delta="Needs attention" if summary["at_risk_count"] else "On track", delta_color="inverse")

    left, right = st.columns([1.45, 1])
    with left:
        st.subheader("Subject performance")
        subjects = summary["subjects"]
        if subjects:
            import pandas as pd
            chart_df = pd.DataFrame({"Subject": list(subjects), "Average": [x["avg"] for x in subjects.values()]})
            st.bar_chart(chart_df, x="Subject", y="Average")
            st.caption("Dashed threshold markers are available in the subject breakdown table below.")
            st.dataframe(
                pd.DataFrame([
                    {"Subject": s, "Average": v["avg"], "Students": v["count"], "Lowest": v["min"], "Highest": v["max"], "Trend": v["slope"]}
                    for s, v in subjects.items()
                ]), use_container_width=True, hide_index=True
            )
        else:
            st.info("No subject records yet. Add a record or import a CSV to see analytics.")
    with right:
        st.subheader("Grade distribution")
        if records:
            import pandas as pd
            grade_order = ["A+", "A", "B", "C", "D", "F"]
            counts = {g: sum(1 for r in records if r.grade == g) for g in grade_order}
            grade_df = pd.DataFrame({"Grade": grade_order, "Records": [counts[g] for g in grade_order]})
            st.bar_chart(grade_df, x="Grade", y="Records")
            st.markdown("**Outcome split**")
            st.write(f"🏅 Honors: **{summary['honors_count']}**")
            st.write(f"✅ Pass: **{sum(1 for r in records if r.status == 'PASS')}**")
            st.write(f"⚠️ At risk: **{summary['at_risk_count']}**")
        else:
            st.info("No data available yet.")

    st.subheader("Recent records")
    st.dataframe(records_frame(sorted(records, key=lambda r: r.recorded_at, reverse=True)[:8]), use_container_width=True, hide_index=True)
    st.subheader("Needs attention")
    alerts = engine.detect_anomalies()
    if alerts:
        st.dataframe(
            records_frame([x[0] for x in alerts[:10]]).assign(Alert=[x[2] for x in alerts[:10]]),
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.success("No threshold breaches or statistical anomalies detected.")

elif page == "Student Records":
    header("Student Records", "Search, filter and review academic records.")
    c1, c2, c3 = st.columns(3)
    query = c1.text_input("Search", placeholder="Name, ID or subject")
    subjects = sorted({r.subject for r in records})
    selected_subject = c2.selectbox("Subject", ["All"] + subjects)
    statuses = ["All", "PASS", "HONORS", "AT_RISK"]
    selected_status = c3.selectbox("Status", statuses)
    filtered = records
    if query.strip():
        q = query.strip().casefold()
        filtered = [r for r in filtered if q in r.student_id.casefold() or q in r.student_name.casefold() or q in r.subject.casefold() or q in r.term.casefold()]
    if selected_subject != "All":
        filtered = [r for r in filtered if r.subject == selected_subject]
    if selected_status != "All":
        filtered = [r for r in filtered if r.status == selected_status]
    st.caption(f"Showing {len(filtered)} of {len(records)} records")
    st.dataframe(records_frame(filtered), use_container_width=True, hide_index=True)
    if filtered:
        csv_bytes = records_frame(filtered).to_csv(index=False).encode("utf-8")
        st.download_button("⬇ Download filtered records CSV", csv_bytes, "filtered_records.csv", "text/csv")

elif page == "Add Record":
    header("Add Student Record", "Create a validated academic entry. Your data is saved with integrity protection.")
    with st.form("add_record_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        sid = c1.text_input("Student ID", placeholder="STU015")
        student_name = c2.text_input("Student name", placeholder="Student full name")
        subject = c1.text_input("Subject", placeholder="Mathematics")
        score = c2.number_input("Score", min_value=0.0, max_value=100.0, step=0.5)
        term = c1.text_input("Term", value="Term 1")
        submitted = st.form_submit_button("Save record", type="primary", use_container_width=True)
    if submitted:
        try:
            rec = core.PerformanceRecord(student_id=sid, student_name=student_name, subject=subject, score=score, term=term)
            duplicate = any(r.student_id == rec.student_id and r.subject.casefold() == rec.subject.casefold() and r.term.casefold() == rec.term.casefold() for r in records)
            if duplicate:
                st.warning("This student already has a record for this subject and term. Please check before adding a duplicate.")
            elif len(records) >= core.MAX_RECORDS:
                st.error(f"Record capacity ({core.MAX_RECORDS}) reached.")
            else:
                records.append(rec)
                core.save_records_atomic(records)
                st.session_state.records = records
                st.success(f"Saved {rec.student_id} — {rec.subject}: {rec.score:.1f} ({rec.grade}, {rec.status.replace('_', ' ')})")
                st.rerun()
        except (ValueError, core.SecurityError, OSError) as exc:
            st.error(str(exc))

elif page == "Import CSV":
    header("Bulk Import", "Upload a CSV file and review the import summary. Required columns: student_id, student_name, subject, score.")
    st.markdown("Example headers: `student_id, student_name, subject, score, term, recorded_at`")
    upload = st.file_uploader("Choose CSV file", type=["csv"])
    if upload is not None:
        try:
            decoded = upload.getvalue().decode("utf-8-sig")
            reader = csv.DictReader(io.StringIO(decoded))
            required = {"student_id", "student_name", "subject", "score"}
            headers = {h.strip().lower() for h in (reader.fieldnames or [])}
            if not required.issubset(headers):
                st.error("CSV missing required columns: student_id, student_name, subject, score")
            else:
                raw_rows = list(reader)
                st.caption(f"Preview: {len(raw_rows)} row(s)")
                st.dataframe(raw_rows[:20], use_container_width=True, hide_index=True)
                if st.button("Import valid rows", type="primary"):
                    added, errors = 0, []
                    seen = {(r.student_id, r.subject.casefold(), r.term.casefold()) for r in records}
                    normalized_headers = [h.strip().lower() for h in (reader.fieldnames or [])]
                    for line, raw in enumerate(raw_rows, start=2):
                        row = {k.strip().lower(): v for k, v in raw.items() if k}
                        try:
                            rec = core.PerformanceRecord(
                                student_id=row.get("student_id", ""), student_name=row.get("student_name", ""),
                                subject=row.get("subject", ""), score=row.get("score", ""),
                                term=row.get("term") or "Term 1", recorded_at=row.get("recorded_at") or __import__("datetime").date.today().isoformat(),
                            )
                            key = (rec.student_id, rec.subject.casefold(), rec.term.casefold())
                            if key in seen:
                                raise ValueError("Duplicate student/subject/term record")
                            if len(records) + added >= core.MAX_RECORDS:
                                raise ValueError(f"Record limit ({core.MAX_RECORDS}) reached")
                            records.append(rec)
                            seen.add(key)
                            added += 1
                        except Exception as exc:
                            errors.append(f"Row {line}: {exc}")
                    if added:
                        core.save_records_atomic(records)
                        st.session_state.records = records
                    st.success(f"Imported {added} valid record(s).")
                    if errors:
                        st.warning(f"Skipped {len(errors)} row(s):")
                        st.code("\n".join(errors[:20]))
                    st.rerun()
        except UnicodeDecodeError:
            st.error("Unable to read CSV as UTF-8. Please save the file as UTF-8 and try again.")
        except Exception as exc:
            st.error(f"Import failed: {exc}")

elif page == "Reports":
    header("Export Reports", "Create CSV, Markdown and chart files, then download them directly.")
    base_name = st.text_input("Report name", value="academic_report")
    if st.button("Generate reports", type="primary"):
        try:
            files = core.export_reports(records, base_name)
            st.success("Report files generated successfully.")
            for path in files:
                st.write(f"📄 `{path.relative_to(BASE_DIR)}`")
        except (ValueError, core.SecurityError, OSError) as exc:
            st.error(str(exc))
    st.divider()
    existing_exports = sorted(core.EXPORT_DIR.glob("*")) if core.EXPORT_DIR.exists() else []
    if existing_exports:
        st.subheader("Available exports")
        for path in existing_exports:
            if path.is_file() and path.suffix.lower() in {".csv", ".md", ".png"}:
                mime = {".csv": "text/csv", ".md": "text/markdown", ".png": "image/png"}.get(path.suffix.lower(), "application/octet-stream")
                st.download_button(f"⬇ {path.name}", path.read_bytes(), path.name, mime, key=f"download_{path.name}")

elif page == "Alerts":
    header("Alerts & Insights", "Identify low scores and statistical outliers for follow-up.")
    alerts = engine.detect_anomalies()
    st.metric("Alerts", len(alerts))
    if alerts:
        alert_rows = []
        for rec, z, reason in alerts:
            alert_rows.append({"Student ID": rec.student_id, "Student": rec.student_name, "Subject": rec.subject, "Score": rec.score, "Grade": rec.grade, "Z-score": z, "Reason": reason})
        st.dataframe(alert_rows, use_container_width=True, hide_index=True)
        st.info("A low-score alert is a flag for review, not a conclusion about the student. Check context and prior performance.")
    else:
        st.success("No alerts for the current records.")

st.caption("Academic Performance Dashboard · Original command-line application remains available as academic_dashboard.py")
